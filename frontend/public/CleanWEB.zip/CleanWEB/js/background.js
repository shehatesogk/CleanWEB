import { defaultBadWords, defaultImageKeywords } from './default_blacklist.js';

const OFFSCREEN_DOCUMENT_PATH = 'js/ml_models/offscreen.html';
let creatingOffscreenDocumentPromise = null; 

const initialSettings = {
  textFilterEnabled: true,
  imageBlurEnabled: true,
  userTextBlacklist: [],
  userImageBlacklist: [], 
  defaultTextBlacklist: defaultBadWords,
  defaultImageKeywords: defaultImageKeywords
};

async function hasOffscreenDocument() {
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
    });
    return contexts && contexts.length > 0;
  } else {
    console.warn("CleanWEB Background: chrome.runtime.getContexts API not available. Cannot reliably check for existing offscreen document without it.");
    return false; 
  }
}

async function ensureOffscreenDocument() {
  if (creatingOffscreenDocumentPromise) {
    console.log("CleanWEB Background: Offscreen document creation/check already in progress. Waiting for existing promise.");
    return creatingOffscreenDocumentPromise;
  }

  creatingOffscreenDocumentPromise = (async () => {
    if (await hasOffscreenDocument()) {
      console.log("CleanWEB Background: Offscreen document already exists.");
      return;
    }

    console.log("CleanWEB Background: Attempting to create offscreen document at:", OFFSCREEN_DOCUMENT_PATH);
    try {
      console.log("CleanWEB Background: Checking available chrome.offscreen.Reason values:", JSON.stringify(chrome.offscreen.Reason, null, 2));
      console.log("CleanWEB Background: Specifically, DOM_PARSER is:", chrome.offscreen.Reason.DOM_PARSER);
      console.log("CleanWEB Background: Specifically, MACHINE_LEARNING is:", chrome.offscreen.Reason.MACHINE_LEARNING);

      await chrome.offscreen.createDocument({
        url: OFFSCREEN_DOCUMENT_PATH,
        reasons: [chrome.offscreen.Reason.DOM_PARSER], 
        justification: 'ML model processing and potential DOM interactions for CleanWEB.',
      });
      console.log("CleanWEB Background: Offscreen document createDocument call finished successfully.");
    } catch (err) {
      console.error("CleanWEB Background: Error calling createDocument for offscreen:", err.message, err);
      creatingOffscreenDocumentPromise = null;
      throw err;
    }
  })();

  try {
    await creatingOffscreenDocumentPromise;
  } catch (finalError) {
    console.log("CleanWEB Background: ensureOffscreenDocument finished with an error that was caught internally (error logged above).");
    creatingOffscreenDocumentPromise = null;
  }
  
  return creatingOffscreenDocumentPromise;
}

chrome.runtime.onInstalled.addListener((details) => {
  console.log("CleanWEB Background: onInstalled event triggered, reason:", details.reason);
  chrome.storage.sync.get(Object.keys(initialSettings), (result) => {
    const currentSettings = {};
    let needsUpdate = false;
    for (const key in initialSettings) {
      if (result[key] === undefined) {
        currentSettings[key] = initialSettings[key];
        needsUpdate = true;
      } else {
        currentSettings[key] = result[key];
      }
    }
    if (details.reason === "install" || details.reason === "update") {
      if (JSON.stringify(result.defaultTextBlacklist) !== JSON.stringify(defaultBadWords)) {
        console.log("CleanWEB Background: Updating defaultTextBlacklist.");
        currentSettings.defaultTextBlacklist = defaultBadWords;
        needsUpdate = true;
      }
      if (JSON.stringify(result.defaultImageKeywords) !== JSON.stringify(defaultImageKeywords)) {
        console.log("CleanWEB Background: Updating defaultImageKeywords.");
        currentSettings.defaultImageKeywords = defaultImageKeywords;
        needsUpdate = true;
      }
    }

    if (needsUpdate) {
      chrome.storage.sync.set(currentSettings, () => {
        console.log('CleanWEB Background: Initial or updated settings saved.');
      });
    }
  });
  ensureOffscreenDocument().catch(err => console.error("CleanWEB Background: Failed to ensure offscreen document on install.", err.message));
});

chrome.runtime.onStartup.addListener(async () => {
  console.log("CleanWEB Background: onStartup event.");
  await ensureOffscreenDocument().catch(err => console.error("CleanWEB Background: Failed to ensure offscreen document on startup.", err.message));
});

(async () => {
  console.log("CleanWEB Background: Service Worker starting, ensuring offscreen document presence.");
  await ensureOffscreenDocument().catch(err => console.error("CleanWEB Background: Failed to ensure offscreen document on initial SW start.", err.message));
})();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const requestAction = request ? request.action : "No action";
  console.log(`CleanWEB Background: Message received - Action: ${requestAction}`, request);

  if (requestAction === "getSettings") {
    chrome.storage.sync.get(null, (settings) => {
      if (chrome.runtime.lastError) {
        console.error("CleanWEB Background: Error getting settings:", chrome.runtime.lastError.message);
        sendResponse({ error: chrome.runtime.lastError.message });
      } else {
        const completeSettings = { ...initialSettings, ...settings };
        sendResponse(completeSettings);
      }
    });
    return true;
  }

  if (requestAction === "saveSettings") {
    chrome.storage.sync.get(null, (currentStoredSettings) => {
      if (chrome.runtime.lastError) {
        console.error("CleanWEB Background (saveSettings): Error getting current settings:", chrome.runtime.lastError.message);
        sendResponse({ success: false, error: "Could not retrieve current settings to merge." });
        return;
      }

      const newMergedSettings = { ...currentStoredSettings, ...request.settings };
      
      chrome.storage.sync.set(newMergedSettings, () => {
        if (chrome.runtime.lastError) {
          console.error("CleanWEB Background (saveSettings): Error saving merged settings:", chrome.runtime.lastError.message);
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
          return;
        }
        console.log("CleanWEB Background (saveSettings): Settings successfully merged and saved:", newMergedSettings);
        sendResponse({ success: true });

        const newSettingsForTabs = newMergedSettings;
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs.length > 0 && tabs[0].id) {
            const tabId = tabs[0].id;
            if (tabs[0].url && (tabs[0].url.startsWith('chrome://') || tabs[0].url.startsWith('edge://'))) {
              return;
            }
            chrome.tabs.sendMessage(tabId, { action: "settingsUpdated", newSettings: newSettingsForTabs })
              .catch(error => { });
          }
        });
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.id) {
              const tabId = tab.id;
              if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('devtools://'))) {
                return;
              }
              chrome.tabs.sendMessage(tabId, { action: "settingsUpdated", newSettings: newSettingsForTabs })
                .catch(error => { });
            }
          });
        });
      });
    });
    return true;
  }


  if (requestAction === 'classifyImageML' || requestAction === 'classifyTextML') {
    (async () => {
      try {
        await ensureOffscreenDocument(); 

        let actionForOffscreen;
        const dataToForward = {}; 
        if (request.action === 'classifyImageML') {
          actionForOffscreen = 'classifyImageNsfw';
          dataToForward.imageDataUrl = request.imageDataUrl; 
        } else if (request.action === 'classifyTextML') {
          actionForOffscreen = 'classifyTextToxicity';
          dataToForward.text = request.text; 
        }

        if (actionForOffscreen) {
          const messageToOffscreen = {
            target: 'offscreen', 
            action: actionForOffscreen,
            ...dataToForward
          };
          console.log("CleanWEB Background: --- Preparing to send message to offscreen ---");
          console.log("CleanWEB Background: Message object type:", typeof messageToOffscreen);
          console.log("CleanWEB Background: Message object content:", JSON.stringify(messageToOffscreen, null, 2));
          console.log("CleanWEB Background: Does message object have 'target' property?", messageToOffscreen.hasOwnProperty('target'));
          console.log("CleanWEB Background: Value of 'target' property:", messageToOffscreen.target);
          console.log("CleanWEB Background: --- Sending now to offscreen ---");

          const response = await chrome.runtime.sendMessage(messageToOffscreen);
          console.log("CleanWEB Background: Received response from offscreen:", response);
          sendResponse(response);
        } else {
          console.warn("CleanWEB Background: Unknown ML action for offscreen based on request:", request.action);
          sendResponse({ error: "Unknown ML action for offscreen" });
        }
      } catch (error) {
        console.error("CleanWEB Background: Error in ML classification flow or communication with offscreen:", error.message, "(Is offscreen document ready and listening?)", error);
        sendResponse({ error: `Failed to communicate with offscreen document: ${error.message}` });
      }
    })();
    return true;
  }
  
  console.warn("CleanWEB Background: Unhandled message action received:", requestAction);
  return false; 
});

console.log("CleanWEB background script loaded and initialized its listeners.");
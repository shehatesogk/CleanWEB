console.log("Скрипт стартанулся");

let nsfwModelInstance = null;
let toxicityModelInstance = null;
let modelsLoadingPromise = null; 
let tempImageElement = null;
let tfjsAndBackendReadyPromise = null; 

const NSFWJS_MODEL_PATH_FROM_ROOT = 'js/ml_models/nsfwjs/model/';
const TOXICITY_MODEL_JSON_PATH_FROM_ROOT = 'ml_models/tfjs_toxicity/model/model.json';
const WASM_BACKEND_PATH_PREFIX_FROM_ROOT = 'lib/wasm/';
const DEFAULT_TOXICITY_THRESHOLD = 0.7;

function initializeTfjsAndBackend() {
    if (tfjsAndBackendReadyPromise) {
        return tfjsAndBackendReadyPromise;
    }
    tfjsAndBackendReadyPromise = new Promise(async (resolve, reject) => {
        const startTime = Date.now();
        const timeout = 30000; 
        const interval = 500;

        async function waitForTfAndSetBackend() {
            if (typeof tf !== 'undefined' && typeof tf.ready === 'function' && typeof tf.setBackend === 'function' && typeof tf.env === 'function') {
                console.log("Offscreen: 'tf' object and core functions found. Attempting tf.ready()...");
                try {
                    await tf.ready(); 
                    console.log("Offscreen: tf.ready() resolved. Default backend (before WASM attempt):", tf.getBackend());
                    console.log("Offscreen: Checking tf.wasm object BEFORE setBackend('wasm'):", typeof tf.wasm, tf.wasm);

                    if (tf.env && typeof tf.env().setFlags === 'function') {
                        console.log("Offscreen: Attempting to disable WASM multi-threading...");
                        tf.env().setFlags({'WASM_HAS_MULTITHREAD_SUPPORT': false});
                        console.log("Offscreen: WASM_HAS_MULTITHREAD_SUPPORT flag set to false.");
                    } else {
                        console.warn("Offscreen: tf.env().setFlags() not available to disable WASM multi-threading.");
                    }

                    const wasmPathAbsolute = chrome.runtime.getURL(WASM_BACKEND_PATH_PREFIX_FROM_ROOT);
                    console.log("Offscreen: Setting WASM paths for TensorFlow.js to:", wasmPathAbsolute);
                    
                    if (tf.wasm && typeof tf.wasm.setWasmPaths === 'function') {
                         tf.wasm.setWasmPaths(wasmPathAbsolute.endsWith('/') ? wasmPathAbsolute : wasmPathAbsolute + '/');
                         console.log("Offscreen: Explicitly called tf.wasm.setWasmPaths().");
                    } else {
                        console.warn("Offscreen: tf.wasm or tf.wasm.setWasmPaths not available for explicit path setting prior to setBackend. Current tf.wasm type:", typeof tf.wasm);
                    }
                    
                    console.log("Offscreen: Attempting to set WASM backend...");
                    await tf.setBackend('wasm');
                    await tf.ready(); 
                    
                    if (tf.getBackend() === 'wasm') {
                        console.log("Offscreen: TensorFlow.js WASM backend successfully initialized!");
                        console.log("Offscreen: tf.wasm object after WASM setup:", typeof tf.wasm, tf.wasm);
                        resolve(); 
                    } else {
                        console.error("Offscreen: Failed to set WASM backend. Current backend:", tf.getBackend(), "Attempting CPU fallback.");
                        await tf.setBackend('cpu');
                        await tf.ready();
                        console.log(`Offscreen: TensorFlow.js backend successfully set to CPU as fallback: ${tf.getBackend()}`);
                        resolve(); 
                    }
                } catch (e) {
                    console.error("Offscreen: Error during tf.ready() or setting backend:", e.message, e.stack);
                    if (Date.now() - startTime < timeout) {
                        setTimeout(waitForTfAndSetBackend, interval);
                    } else {
                        console.error("Offscreen: Timeout reached after error during TFJS/backend initialization.");
                        reject(e); 
                    }
                }
            } else if (Date.now() - startTime > timeout) {
                console.error("Offscreen: Timeout waiting for global 'tf' object (or tf.ready/tf.setBackend/tf.env) to become available.");
                reject(new Error("Timeout: Global 'tf' object or its core functions did not become available."));
            } else {
                setTimeout(waitForTfAndSetBackend, interval);
            }
        }
        console.log("Offscreen: initializeTfjsAndBackend() initiated. Waiting for global 'tf' and backend setup...");
        waitForTfAndSetBackend();
    });
    return tfjsAndBackendReadyPromise;
}

async function loadNsfwModel() {
    if (nsfwModelInstance) {
        console.log("Offscreen: NsfwJS model already loaded.");
        return nsfwModelInstance;
    }
    console.log("Offscreen: Attempting to load NsfwJS model...");
    if (typeof tf === 'undefined' || !tf.getBackend || !tf.getBackend()) {
        console.error("Offscreen: TFJS not ready, cannot load NSFWJS model.");
        throw new Error("TFJS not ready for NSFWJS model loading.");
    }
    if (typeof nsfwjs === 'undefined' || typeof nsfwjs.load !== 'function') {
        console.error("Offscreen: nsfwjs library or nsfwjs.load function is not defined.");
        throw new Error("nsfwjs library not loaded or 'load' function missing");
    }
    try {
        const modelBaseUrl = chrome.runtime.getURL(NSFWJS_MODEL_PATH_FROM_ROOT);
        console.log("Offscreen: NsfwJS model base URL:", modelBaseUrl);
        nsfwModelInstance = await nsfwjs.load(modelBaseUrl, { size: 224 });
        console.log("Offscreen: NsfwJS model LOADED SUCCESSFULLY!");
        return nsfwModelInstance;
    } catch (error) {
        console.error("Offscreen: Error loading NsfwJS model:", error.message, error);
        nsfwModelInstance = null;
        throw error;
    }
}

async function loadToxicityModel() {
    if (toxicityModelInstance) {
        console.log("Offscreen: Toxicity model already loaded.");
        return toxicityModelInstance;
    }
    console.log("Offscreen: Attempting to load Toxicity model...");
     if (typeof tf === 'undefined' || !tf.getBackend || !tf.getBackend()) {
        console.error("Offscreen: TFJS not ready, cannot load Toxicity model.");
        throw new Error("TFJS not ready for Toxicity model loading.");
    }
    if (typeof toxicity === 'undefined' || typeof toxicity.load !== 'function') {
        console.error("Offscreen: toxicity library or toxicity.load function is not defined.");
        throw new Error("toxicity library not loaded or 'load' function missing");
    }
    try {
        const labelsToLoad = ['identity_attack', 'insult', 'obscene', 'severe_toxicity', 'sexual_explicit', 'threat', 'toxicity'];
        console.log("Offscreen: Calling toxicity.load(). Crucial: Ensure your 'toxicity.min.js' correctly handles loading your local model from:", chrome.runtime.getURL(TOXICITY_MODEL_JSON_PATH_FROM_ROOT));
        
        toxicityModelInstance = await toxicity.load(DEFAULT_TOXICITY_THRESHOLD, labelsToLoad);
        
        console.log("Offscreen: Toxicity model LOADED SUCCESSFULLY (presumed, verify it uses local files and not CDN)!");
        return toxicityModelInstance;
    } catch (error) {
        console.error("Offscreen: Error loading Toxicity model:", error.message, error);
        toxicityModelInstance = null;
        throw error;
    }
}

async function initializeModels() {
    console.log("Offscreen: Initializing application models (NSFWJS and Toxicity)...");
    if (!tf || !tf.getBackend || !tf.getBackend()) { 
        console.error("Offscreen: TFJS not ready or no backend set in initializeModels. Skipping application model loading.");
        return; 
    }
    console.log("Offscreen: TFJS backend for model loading: " + tf.getBackend());

    const nsfwPromise = loadNsfwModel().catch(err => {
        console.error("Offscreen: NsfwJS loading failed during initializeModels call:", err.message);
        return null; 
    });
    const toxicityPromise = loadToxicityModel().catch(err => {
        console.error("Offscreen: Toxicity loading failed during initializeModels call:", err.message);
        return null;
    });
    await Promise.allSettled([nsfwPromise, toxicityPromise]);

    if (nsfwModelInstance) console.log("Offscreen: NsfwJS model final status: READY.");
    else console.warn("Offscreen: NsfwJS model final status: NOT READY.");

    if (toxicityModelInstance) console.log("Offscreen: Toxicity model final status: READY.");
    else console.warn("Offscreen: Toxicity model final status: NOT READY.");
}

async function onDomReady() {
    console.log("Offscreen: DOMContentLoaded event fired.");
    tempImageElement = document.getElementById('tempImageForNsfw');
    if (!tempImageElement) {
        console.error("Offscreen: CRITICAL - tempImageForNsfw element NOT FOUND in offscreen.html!");
    } else {
        console.log("Offscreen: tempImageForNsfw element found successfully.");
    }

    try {
        console.log("Offscreen: Attempting to initialize TFJS and set backend...");
        modelsLoadingPromise = initializeTfjsAndBackend().then(() => {
            if (tf && tf.getBackend && tf.getBackend()) {
                 return initializeModels();
            } else {
                console.error("Offscreen: TFJS backend not set after initializeTfjsAndBackend. Models will not be loaded.");
                return Promise.resolve(); 
            }
        });
        
        await modelsLoadingPromise;
        console.log("Offscreen: TFJS and application model initialization sequence complete (check individual statuses).");

    } catch (error) {
        console.error("Offscreen: Failed to initialize TFJS/backend or models:", error.message, error.stack);
        if (!modelsLoadingPromise || typeof modelsLoadingPromise.then !== 'function') { 
             modelsLoadingPromise = Promise.reject(error);
        }
    }
}

if (document.readyState === 'loading') {
    console.log("Offscreen: DOM is loading, adding DOMContentLoaded listener.");
    window.addEventListener('DOMContentLoaded', onDomReady);
} else {
    console.log("Offscreen: DOM already loaded, calling onDomReady directly.");
    onDomReady();
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Offscreen: --- RAW REQUEST OBJECT RECEIVED ---");
    console.log("Offscreen: Typeof request:", typeof request);
    try {
        console.log(JSON.stringify(request, null, 2));
    } catch (e) {
        console.log("Offscreen: Could not stringify request, logging as is:", request);
    }
    console.log("Offscreen: --- END RAW REQUEST OBJECT ---");

    const requestAction = request ? request.action : "No action";
    const requestTarget = request ? request.target : undefined;
    console.log(`Offscreen: Message received - Target: ${requestTarget}, Action: ${requestAction}`);

    if (requestTarget !== 'offscreen') { 
        console.log("Offscreen: Message ignored, target is not 'offscreen'. Current target:", requestTarget);
        return false; 
    }

    (async () => {
        if (!modelsLoadingPromise) {
            console.error("Offscreen: modelsLoadingPromise is not initialized! This indicates an issue in onDomReady.");
            sendResponse({ error: "Models are not being loaded. Offscreen document might not have initialized correctly." });
            return;
        }
        
        try {
            await modelsLoadingPromise; 
            console.log("Offscreen: Model initialization sequence awaited in onMessage. Checking specific model for action:", requestAction);
        } catch (initError) {
            console.error("Offscreen: Error awaiting model initialization promise in onMessage:", initError.message);
            sendResponse({ error: `Model initialization failed: ${initError.message}` });
            return;
        }

        if (requestAction === 'classifyImageNsfw') {
            if (!nsfwModelInstance) {
                console.error("Offscreen: NsfwJS model not available for classifyImageNsfw request.");
                sendResponse({ error: "NsfwJS модель не загружена." });
                return;
            }
            if (!tempImageElement) {
                console.error("Offscreen: tempImageElement is null, cannot classify image.");
                sendResponse({ error: "Ошибка конфигурации Offscreen: tempImageElement отсутствует." });
                return;
            }
            if (!request.imageDataUrl || typeof request.imageDataUrl !== 'string') {
                console.error("Offscreen: imageDataUrl not provided or not a string for classifyImageNsfw.");
                sendResponse({ error: "imageDataUrl не был предоставлен или имеет неверный формат." });
                return;
            }

            tempImageElement.onload = async () => {
                try {
                    console.log("Offscreen: Classifying image with NsfwJS, src first 100 chars:", tempImageElement.src ? String(tempImageElement.src).substring(0, 100) + "..." : "undefined src");
                    const predictions = await nsfwModelInstance.classify(tempImageElement);
                    console.log("Offscreen: NsfwJS predictions:", predictions);
                    sendResponse({ predictions });
                } catch (e) {
                    console.error("Offscreen: NsfwJS classification error:", e);
                    sendResponse({ error: e.toString() });
                }
            };
            tempImageElement.onerror = () => {
                console.error("Offscreen: Failed to load image into temp element for NsfwJS. Passed URL first 100 chars:", request.imageDataUrl ? String(request.imageDataUrl).substring(0, 100) + "..." : "undefined");
                sendResponse({ error: "Не удалось загрузить изображение для NsfwJS в offscreen." });
            };
            tempImageElement.src = request.imageDataUrl;


        } else if (requestAction === 'classifyTextToxicity') {
            if (!toxicityModelInstance) {
                console.error("Offscreen: Toxicity model not available for classifyTextToxicity request.");
                sendResponse({ status: 'error', error: "Toxicity модель не загружена." });
                return;
            }

            const textToClassify = request.text;
            if (typeof textToClassify !== 'string' && !Array.isArray(textToClassify)) {
                console.error("Offscreen: Invalid text input for Toxicity. Expected string or array of strings.");
                sendResponse({ status: 'error', error: "Неверный формат текста для Toxicity." });
                return;
            }
            
            try {
                console.log(`Offscreen: Classifying text for toxicity: "${String(textToClassify).substring(0, 50)}..."`);
                const inputsToClassify = Array.isArray(textToClassify) ? textToClassify : [textToClassify];
                const predictions = await toxicityModelInstance.classify(inputsToClassify);
                console.log("Offscreen: Toxicity predictions (raw):", predictions);

                const results = predictions.map(pred => ({
                    label: pred.label,
                    match: pred.results[0].match,
                    probability: pred.results[0].probabilities[1]
                }));
                
                console.log("Offscreen: Toxicity results (processed):", results);
                sendResponse({ status: 'success', results: results });
            } catch (e) {
                console.error("Offscreen: Toxicity classification error:", e);
                sendResponse({ status: 'error', error: e.toString() });
            }
        } else {
            console.warn("Offscreen: Unknown action received:", requestAction);
            sendResponse({ error: "Неизвестное действие для offscreen: " + requestAction });
        }
    })(); 

    return true;
});
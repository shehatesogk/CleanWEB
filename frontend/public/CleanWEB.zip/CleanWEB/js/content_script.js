// js/content_script.js

const initialSettingsForContentScript = {
  textFilterEnabled: true,
  mlTextFilterEnabled: false,
  imageBlurEnabled: true,
  userTextBlacklist: [],
  userImageBlacklist: [],
  defaultTextBlacklist: [],
  defaultImageKeywords: [],
  allTextBlacklist: []
};

let currentSettings = JSON.parse(JSON.stringify(initialSettingsForContentScript));

const CENSOR_PLACEHOLDER = "[censored]";
const ML_CENSOR_PLACEHOLDER_TEXT = "[Содержимое скрыто: ML обнаружил нежелательный текст]";
const BLUR_CLASS = "cleanweb-blurred-image";
const PROCESSED_FLAG_ML = 'cleanweb-processed-ml';
const PROCESSED_FLAG_ML_TEXT = 'cleanweb-processed-ml-text';


function censorTextNode(node, textBlacklist) {
  if (!node || !node.nodeValue || !textBlacklist || textBlacklist.length === 0) {
    return;
  }
  let content = node.nodeValue;
  let originalContent = content;
  textBlacklist.forEach(word => {
    const regex = new RegExp(`(?<![\\p{L}\\p{N}_])${word}(?![\\p{L}\\p{N}_])`, 'giu');
    if (content.match(regex)) {
      content = content.replace(regex, CENSOR_PLACEHOLDER);
    }
  });
  if (content !== originalContent) {
    node.nodeValue = content;
  }
}

function scanAndCensorTextByKeywords() {
  if (!currentSettings.textFilterEnabled || !currentSettings.allTextBlacklist || currentSettings.allTextBlacklist.length === 0) {
    return;
  }
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
  let node;
  while (node = walker.nextNode()) {
    if (node.parentElement && (
        node.parentElement.tagName === 'SCRIPT' ||
        node.parentElement.tagName === 'STYLE' ||
        node.parentElement.isContentEditable ||
        node.parentElement.closest(`.${BLUR_CLASS}`) ||
        node.parentElement.closest(`[data-${PROCESSED_FLAG_ML_TEXT}]`)
        )) {
      continue;
    }
    censorTextNode(node, currentSettings.allTextBlacklist);
  }
}

async function scanAndCensorTextByML() {
    if (!currentSettings.textFilterEnabled || !currentSettings.mlTextFilterEnabled) {
        return;
    }
    console.log("CleanWEB ContentScript: Starting ML text scan...");

    const selectors = 'p, div:not(:has(div, p, ul, ol, table, article, section, header, footer, nav, aside)), li, span, h1, h2, h3, h4, h5, h6, article, section, td';
    const elements = document.querySelectorAll(selectors);
    const minTextLengthForML = 20;

    for (const el of elements) {
        if (el.hasAttribute(`data-${PROCESSED_FLAG_ML_TEXT}`) || el.closest(`[data-${PROCESSED_FLAG_ML_TEXT}]`)) {
            continue;
        }
        if (el.isContentEditable || el.closest('script, style, textarea, input')) {
            continue;
        }

        let textContent = el.textContent ? el.textContent.trim() : "";
        textContent = textContent.replace(/\s+/g, ' '); 

        if (textContent.length >= minTextLengthForML) {
            el.dataset.cleanwebProcessingMlText = 'true'; 
            console.log(`CleanWEB ContentScript: Sending text block for ML Toxicity check (length ${textContent.length}): "${textContent.substring(0, 100)}..."`);
            try {
                const response = await chrome.runtime.sendMessage({
                    action: 'classifyTextML',
                    text: textContent
                });

                console.log(`CleanWEB ContentScript: ML Toxicity Response for text block:`, response);
                if (response && response.status === 'success' && response.results) {
                    const toxicLabels = ['toxicity', 'severe_toxicity', 'obscene', 'insult', 'threat'];
                    let isToxic = false;
                    for (const result of response.results) {
                        if (toxicLabels.includes(result.label) && result.match === true) {
                            if (result.probability > (currentSettings.mlTextThreshold || 0.85) ) { 
                                console.log(`CleanWEB ContentScript: ML found toxic label '${result.label}' (Prob: ${result.probability.toFixed(2)}) for text block. Replacing content.`);
                                isToxic = true;
                                break;
                            }
                        }
                    }
                    if (isToxic) {
                        el.innerHTML = `<span style="color:red; font-style:italic;">${ML_CENSOR_PLACEHOLDER_TEXT}</span>`;
                    }
                } else if (response && response.error) {
                    console.warn(`CleanWEB ContentScript: ML Toxicity classification error for text block:`, response.error);
                }
            } catch (error) {
                console.error(`CleanWEB ContentScript: Error sending text block for ML classification: ${error.message}`, error);
            }
            el.setAttribute(`data-${PROCESSED_FLAG_ML_TEXT}`, 'true');
            delete el.dataset.cleanwebProcessingMlText;
        } else {
            if (textContent.length > 0) el.setAttribute(`data-${PROCESSED_FLAG_ML_TEXT}`, 'skipped-too-short');
        }
    }
    console.log("CleanWEB ContentScript: Finished ML text scan.");
}


function blurImage(imgElement, reason = "rule") {
  if (!imgElement.classList.contains(BLUR_CLASS)) {
    console.log(`CleanWEB ContentScript: BLURRING image (reason: ${reason}):`, imgElement.src ? imgElement.src.substring(0,100) + "..." : "[no src]");
    imgElement.classList.add(BLUR_CLASS);
  }
}

function unblurImage(imgElement) {
    // ... (ваш код unblurImage)
    if (imgElement.classList.contains(BLUR_CLASS)) {
        console.log("CleanWEB ContentScript: UNBLURRING image:", imgElement.src ? imgElement.src.substring(0,100) + "..." : "[no src]");
        imgElement.classList.remove(BLUR_CLASS);
    }
}

async function scanAndModerateImages() {
  if (!currentSettings.imageBlurEnabled) {
    document.querySelectorAll(`img.${BLUR_CLASS}`).forEach(unblurImage);
    document.querySelectorAll(`img[data-${PROCESSED_FLAG_ML}]`).forEach(img => img.removeAttribute(`data-${PROCESSED_FLAG_ML}`));
    return;
  }

  const images = document.querySelectorAll(`img:not([data-${PROCESSED_FLAG_ML}])`);
  const userImageRules = currentSettings.userImageBlacklist || [];
  const defaultImageKeywordsArray = currentSettings.defaultImageKeywords || [];

  for (const img of images) {
    img.dataset.cleanwebProcessingScan = 'true';

    if (!img.src || img.closest(`a[href="${img.src}"]`)) {
        img.setAttribute(`data-${PROCESSED_FLAG_ML}`, 'skipped-no-src-or-self-link');
        delete img.dataset.cleanwebProcessingScan;
        continue;
    }
    
    let isBlurredByRule = false;

    const matchedUrlRule = userImageRules.find(rule => rule.type === 'url' && img.src.includes(rule.value));
    if (matchedUrlRule) {
      blurImage(img, `user URL rule: '${matchedUrlRule.value}'`);
      isBlurredByRule = true;
    }

    if (!isBlurredByRule) {
      const matchedKeywordRule = userImageRules.find(rule => {
        if (rule.type === 'keyword') {
          const altText = (img.alt || "").toLowerCase();
          const titleText = (img.title || "").toLowerCase();
          const keyword = String(rule.value || "").toLowerCase();
          return keyword && (altText.includes(keyword) || titleText.includes(keyword));
        }
        return false;
      });
      if (matchedKeywordRule) {
        blurImage(img, `user keyword rule: '${matchedKeywordRule.value}'`);
        isBlurredByRule = true;
      }
    }
    
    if (!isBlurredByRule) {
        const matchedDefaultKeyword = defaultImageKeywordsArray.find(keyword => {
            const altText = (img.alt || "").toLowerCase();
            const titleText = (img.title || "").toLowerCase();
            const lowerKeyword = String(keyword || "").toLowerCase(); 
            return lowerKeyword && (altText.includes(lowerKeyword) || titleText.includes(lowerKeyword));
        });
        if (matchedDefaultKeyword) {
            blurImage(img, `default keyword rule: '${matchedDefaultKeyword}'`);
            isBlurredByRule = true;
        }
    }
    
    if (!isBlurredByRule && currentSettings.imageBlurEnabled) {
      console.log(`CleanWEB ContentScript: Sending image for ML classification: ${img.src ? img.src.substring(0,100) : "[no src]"}...`);
      try {
        const response = await chrome.runtime.sendMessage({
          action: 'classifyImageML', 
          imageDataUrl: img.src 
        });

        console.log(`CleanWEB ContentScript: ML Response for ${img.src ? img.src.substring(0,100) : "[no src]"}:`, response);
        if (response && response.predictions) {
          const nsfwCategories = ["Porn", "Hentai", "Sexy"]; 
          const threshold = 0.6; 

          for (const prediction of response.predictions) {
            if (nsfwCategories.includes(prediction.className) && prediction.probability > threshold) {
              blurImage(img, `ML: ${prediction.className} (Prob: ${prediction.probability.toFixed(2)})`);
              break; 
            }
          }
        } else if (response && response.error) {
            console.warn(`CleanWEB ContentScript: ML classification error for ${img.src ? img.src.substring(0,100) : "[no src]"}:`, response.error);
        }
      } catch (error) {
        console.error(`CleanWEB ContentScript: Error sending/receiving ML message for ${img.src ? img.src.substring(0,100) : "[no src]"}: ${error.message}`, error);
      }
    }
    img.setAttribute(`data-${PROCESSED_FLAG_ML}`, 'true'); 
    delete img.dataset.cleanwebProcessingScan;
  }
}


// --- Основная логика и наблюдатель ---
function applyModeration(forceFullScan = false) {
  console.log("CleanWEB ContentScript: Applying moderation. Force full scan:", forceFullScan, "Settings:", JSON.parse(JSON.stringify(currentSettings)));
  if (forceFullScan) { 
      document.querySelectorAll(`img[data-${PROCESSED_FLAG_ML}]`).forEach(img => img.removeAttribute(`data-${PROCESSED_FLAG_ML}`));
      document.querySelectorAll(`[data-${PROCESSED_FLAG_ML_TEXT}]`).forEach(el => el.removeAttribute(`data-${PROCESSED_FLAG_ML_TEXT}`));
  }

  if (currentSettings.textFilterEnabled) {
    scanAndCensorTextByKeywords();
    if (currentSettings.mlTextFilterEnabled) {
        scanAndCensorTextByML();
    }
  }
  scanAndModerateImages(); 
}

const observer = new MutationObserver((mutationsList) => {
  let needsModeration = false;
  for (const mutation of mutationsList) {
    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        let relevantChange = false;
        mutation.addedNodes.forEach(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
                 if (!node.classList.contains(BLUR_CLASS) && 
                     !node.hasAttribute(`data-${PROCESSED_FLAG_ML}`) && 
                     !node.hasAttribute(`data-${PROCESSED_FLAG_ML_TEXT}`) &&
                     !node.closest(`[data-${PROCESSED_FLAG_ML}]`) &&
                     !node.closest(`[data-${PROCESSED_FLAG_ML_TEXT}]`)
                    ) {
                    relevantChange = true;
                }
            } else if (node.nodeType === Node.TEXT_NODE) { 
                // Если текстовый узел добавлен не в уже обработанный ML блок
                if (!node.parentElement || !node.parentElement.closest(`[data-${PROCESSED_FLAG_ML_TEXT}]`)) {
                    relevantChange = true;
                }
            }
        });
        if (relevantChange) {
            needsModeration = true;
            break;
        }
    } else if (mutation.type === 'attributes' && 
               (mutation.attributeName === 'src' || mutation.attributeName === 'alt' || mutation.attributeName === 'title') && 
               mutation.target.tagName === 'IMG') {
        mutation.target.removeAttribute(`data-${PROCESSED_FLAG_ML}`);
        needsModeration = true;
        break;
    }
  }
  if (needsModeration) {
    applyModeration();
  }
});

function startObserver() {
  if (document.body) { 
    console.log("CleanWEB ContentScript: Starting MutationObserver.");
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'alt', 'title'] });
  } else {
    console.warn("CleanWEB ContentScript: document.body not found at startObserver. Retrying on DOMContentLoaded.");
    document.addEventListener('DOMContentLoaded', () => {
        if (document.body) {
             console.log("CleanWEB ContentScript: Starting MutationObserver after DOMContentLoaded.");
            observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'alt', 'title'] });
        } else {
            console.error("CleanWEB ContentScript: document.body still not found after DOMContentLoaded.");
        }
    }, { once: true });
  }
}

function initialize() {
    console.log("CleanWEB ContentScript: Initializing...");
    chrome.runtime.sendMessage({ action: "getSettings" }, (settingsFromBg) => {
      if (chrome.runtime.lastError) {
        console.error("CleanWEB ContentScript: Error getting initial settings:", chrome.runtime.lastError.message);
        currentSettings = JSON.parse(JSON.stringify(initialSettingsForContentScript)); 
        console.warn("CleanWEB ContentScript: Using default initial settings due to error.");
      } else {
        console.log("CleanWEB ContentScript: Initial settings received from background.");
        currentSettings = { ...initialSettingsForContentScript, ...settingsFromBg };
      }

      currentSettings.allTextBlacklist = [
        ...(currentSettings.defaultTextBlacklist || []),
        ...(currentSettings.userTextBlacklist || [])
      ].map(word => String(word || "").trim().toLowerCase())
       .filter(Boolean)
       .filter((v, i, a) => a.indexOf(v) === i && v.length > 0);
      console.log("CleanWEB ContentScript: Initial combined allTextBlacklist count:", (currentSettings.allTextBlacklist || []).length);
      console.log("CleanWEB ContentScript: Final currentSettings after init:", JSON.parse(JSON.stringify(currentSettings)));

      applyModeration(true); 
      startObserver();
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) { 
    return;
  }

  if (request.action === "settingsUpdated") {
    console.log("CleanWEB ContentScript: Settings updated message received.");
    const oldImageBlurEnabled = currentSettings.imageBlurEnabled;
    const oldTextFilterEnabled = currentSettings.textFilterEnabled;
    const oldMlTextFilterEnabled = currentSettings.mlTextFilterEnabled;

    currentSettings = { ...initialSettingsForContentScript, ...request.newSettings };
    
    currentSettings.allTextBlacklist = [
        ...(currentSettings.defaultTextBlacklist || []),
        ...(currentSettings.userTextBlacklist || [])
    ].map(word => String(word || "").trim().toLowerCase())
     .filter(Boolean)
     .filter((v, i, a) => a.indexOf(v) === i && v.length > 0);
    console.log("CleanWEB ContentScript: Updated combined allTextBlacklist count:", (currentSettings.allTextBlacklist || []).length);
    console.log("CleanWEB ContentScript: Final currentSettings after update:", JSON.parse(JSON.stringify(currentSettings)));

    let forceRescan = false;
    if (oldImageBlurEnabled !== currentSettings.imageBlurEnabled || 
        oldTextFilterEnabled !== currentSettings.textFilterEnabled ||
        oldMlTextFilterEnabled !== currentSettings.mlTextFilterEnabled
        ) {
        forceRescan = true;
    }
    
    if (!currentSettings.imageBlurEnabled) { 
        document.querySelectorAll(`img.${BLUR_CLASS}`).forEach(unblurImage);
    }

    applyModeration(forceRescan); 
    if (typeof sendResponse === 'function') {
      sendResponse({ success: true, message: "Settings received and applied by content_script" });
    }
  }
});

initialize(); 
console.log("CleanWEB content script loaded. Initializing and ready to receive settings.");
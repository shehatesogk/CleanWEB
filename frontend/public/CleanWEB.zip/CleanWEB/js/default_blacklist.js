export const defaultBadWords = [
  "дурак",
  "идиот",
  "черт",
  "пидор",
  "сука"
];

export const defaultImageKeywords = [
  "кровь",
  "насилие",
];
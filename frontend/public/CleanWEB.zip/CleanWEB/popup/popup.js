// popup/popup.js
document.addEventListener('DOMContentLoaded', () => {
  const textFilterToggle = document.getElementById('textFilterToggle');
  const mlTextFilterToggle = document.getElementById('mlTextFilterToggle');
  const imageBlurToggle = document.getElementById('imageBlurToggle');
  
  const textFilterToggleContainer = document.getElementById('textFilterToggleContainer');
  const mlTextFilterToggleContainer = document.getElementById('mlTextFilterToggleContainer');

  const manageBlacklistLink = document.getElementById('manageBlacklistLink');

  const defaultPopupSettings = {
    textFilterEnabled: true,
    mlTextFilterEnabled: false,
    imageBlurEnabled: true
  };

  function handleSaveResponse(settingName, response) {
    if (chrome.runtime.lastError) {
      console.error(`CleanWEB Popup: Error saving ${settingName}:`, chrome.runtime.lastError.message);
      return;
    }
    if (response && response.success) {
      console.log(`CleanWEB Popup: Setting '${settingName}' saved successfully.`);
    } else {
      console.error(`CleanWEB Popup: Failed to save '${settingName}'. Response:`, response);
    }
  }

  function updateMlTextToggleState() {
    if (textFilterToggle && mlTextFilterToggle && mlTextFilterToggleContainer) {
      const isTextFilterOverallEnabled = textFilterToggle.checked;
      mlTextFilterToggle.disabled = !isTextFilterOverallEnabled;
      mlTextFilterToggleContainer.classList.toggle('disabled-setting', !isTextFilterOverallEnabled);
      
      if (!isTextFilterOverallEnabled && mlTextFilterToggle.checked) {
        mlTextFilterToggle.checked = false;
        const newSetting = { mlTextFilterEnabled: false };
        console.log("CleanWEB Popup: Auto-disabling and sending to save:", newSetting);
        chrome.runtime.sendMessage(
          { action: "saveSettings", settings: newSetting },
          (response) => handleSaveResponse("mlTextFilterEnabled (auto-disabled)", response)
        );
      }
    }
  }

  chrome.runtime.sendMessage({ action: "getSettings" }, (settings) => {
    if (chrome.runtime.lastError) {
      console.error("CleanWEB Popup: Error loading initial settings:", chrome.runtime.lastError.message);
      if (textFilterToggle) textFilterToggle.checked = defaultPopupSettings.textFilterEnabled;
      if (mlTextFilterToggle) mlTextFilterToggle.checked = defaultPopupSettings.mlTextFilterEnabled;
      if (imageBlurToggle) imageBlurToggle.checked = defaultPopupSettings.imageBlurEnabled;
    } else if (settings) {
      console.log("CleanWEB Popup: Settings loaded", settings);
      if (textFilterToggle) textFilterToggle.checked = typeof settings.textFilterEnabled === 'boolean' ? settings.textFilterEnabled : defaultPopupSettings.textFilterEnabled;
      if (mlTextFilterToggle) mlTextFilterToggle.checked = typeof settings.mlTextFilterEnabled === 'boolean' ? settings.mlTextFilterEnabled : defaultPopupSettings.mlTextFilterEnabled;
      if (imageBlurToggle) imageBlurToggle.checked = typeof settings.imageBlurEnabled === 'boolean' ? settings.imageBlurEnabled : defaultPopupSettings.imageBlurEnabled;
    } else {
      console.warn("CleanWEB Popup: No settings received from background. Using defaults.");
      if (textFilterToggle) textFilterToggle.checked = defaultPopupSettings.textFilterEnabled;
      if (mlTextFilterToggle) mlTextFilterToggle.checked = defaultPopupSettings.mlTextFilterEnabled;
      if (imageBlurToggle) imageBlurToggle.checked = defaultPopupSettings.imageBlurEnabled;
    }
    updateMlTextToggleState();
  });

  if (textFilterToggle) {
    textFilterToggle.addEventListener('change', () => {
      const newSetting = { textFilterEnabled: textFilterToggle.checked };
      console.log("CleanWEB Popup: Sending to save:", newSetting);
      chrome.runtime.sendMessage(
        { action: "saveSettings", settings: newSetting },
        (response) => handleSaveResponse("textFilterEnabled", response)
      );
      updateMlTextToggleState();
    });
  }

  if (mlTextFilterToggle) {
    mlTextFilterToggle.addEventListener('change', () => {
      const newSetting = { mlTextFilterEnabled: mlTextFilterToggle.checked };
      console.log("CleanWEB Popup: Sending to save:", newSetting);
      chrome.runtime.sendMessage(
        { action: "saveSettings", settings: newSetting },
        (response) => handleSaveResponse("mlTextFilterEnabled", response)
      );
    });
  }
  
  if (imageBlurToggle) {
    imageBlurToggle.addEventListener('change', () => {
      const newSetting = { imageBlurEnabled: imageBlurToggle.checked };
      console.log("CleanWEB Popup: Sending to save:", newSetting);
      chrome.runtime.sendMessage(
        { action: "saveSettings", settings: newSetting },
        (response) => handleSaveResponse("imageBlurEnabled", response)
      );
    });
  }


  if (manageBlacklistLink) {
    manageBlacklistLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        console.warn("CleanWEB Popup: chrome.runtime.openOptionsPage API not available.");
      }
    });
  } else {
     console.error("CleanWEB Popup: manageBlacklistLink element not found!");
  }

  console.log("CleanWEB Popup script loaded and listeners attached.");
});
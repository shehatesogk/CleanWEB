// options/options.js
document.addEventListener('DOMContentLoaded', () => {
  const newTextBlacklistWordInput = document.getElementById('newTextBlacklistWord');
  const addTextWordBtn = document.getElementById('addTextWordBtn');
  const userTextBlacklistUl = document.getElementById('userTextBlacklist');

  const newImageUrlOrKeywordInput = document.getElementById('newImageUrlOrKeyword');
  const imageRuleTypeSelect = document.getElementById('imageRuleType');
  const addImageRuleBtn = document.getElementById('addImageRuleBtn');
  const userImageBlacklistUl = document.getElementById('userImageBlacklist');

  const textFilterToggleOpts = document.getElementById('textFilterToggleOpts');
  const mlTextFilterToggleOpts = document.getElementById('mlTextFilterToggleOpts');
  const imageBlurToggleOpts = document.getElementById('imageBlurToggleOpts');
  
  const mlTextThresholdInput = document.getElementById('mlTextThresholdInput');
  const mlTextSettingsSection = document.getElementById('mlTextSettingsSection');
  
  const defaultTextBlacklistDisplayUl = document.getElementById('defaultTextBlacklistDisplay');
  const defaultImageKeywordsDisplayUl = document.getElementById('defaultImageKeywordsDisplay');

  const defaultPageSettings = {
    textFilterEnabled: true,
    mlTextFilterEnabled: false, 
    mlTextThreshold: 0.85,    
    imageBlurEnabled: true,
    userTextBlacklist: [],
    userImageBlacklist: [],
    defaultTextBlacklist: [],
    defaultImageKeywords: []
  };

  let currentSettings = JSON.parse(JSON.stringify(defaultPageSettings));

  function saveSpecificSettings(settingsToUpdate) {
    chrome.runtime.sendMessage({ action: "saveSettings", settings: settingsToUpdate }, response => {
      if (chrome.runtime.lastError) {
        console.error("CleanWEB Options: Save error:", chrome.runtime.lastError.message, "Details:", settingsToUpdate);
        alert("Ошибка сохранения настроек. Попробуйте еще раз.");
      } else if (response && response.success) {
        console.log("CleanWEB Options: Settings saved successfully:", settingsToUpdate);
      } else {
        console.error("CleanWEB Options: Save failed, response:", response, "Details:", settingsToUpdate);
        alert("Не удалось сохранить настройки. Ответ от background:" + JSON.stringify(response));
      }
    });
  }
  
  function saveBlacklistSettings() {
    const settingsToSave = {
        userTextBlacklist: currentSettings.userTextBlacklist,
        userImageBlacklist: currentSettings.userImageBlacklist
    };
    saveSpecificSettings(settingsToSave);
  }

  // --- Текстовый черный список ---
  function renderTextBlacklist() {
    if (!userTextBlacklistUl) return;
    userTextBlacklistUl.innerHTML = '';
    (currentSettings.userTextBlacklist || []).forEach((word, index) => {
      const li = document.createElement('li');
      const spanValue = document.createElement('span');
      spanValue.className = 'list-item-value';
      spanValue.textContent = word;
      li.appendChild(spanValue);

      const removeBtn = document.createElement('button');
      removeBtn.innerHTML = '&#10007;';
      removeBtn.className = 'remove-btn';
      removeBtn.title = 'Удалить';
      removeBtn.dataset.index = index;
      removeBtn.addEventListener('click', (e) => {
        const itemIndex = parseInt(e.target.dataset.index, 10);
        if (!isNaN(itemIndex) && itemIndex >= 0 && itemIndex < currentSettings.userTextBlacklist.length) {
            currentSettings.userTextBlacklist.splice(itemIndex, 1);
            renderTextBlacklist();
            saveBlacklistSettings();
        }
      });
      li.appendChild(removeBtn);
      userTextBlacklistUl.appendChild(li);
    });
  }

  if (addTextWordBtn && newTextBlacklistWordInput) {
    addTextWordBtn.addEventListener('click', () => {
      const word = newTextBlacklistWordInput.value.trim().toLowerCase();
      if (word) {
        if (!currentSettings.userTextBlacklist) currentSettings.userTextBlacklist = [];
        if (!currentSettings.userTextBlacklist.includes(word)) {
          currentSettings.userTextBlacklist.push(word);
          newTextBlacklistWordInput.value = '';
          renderTextBlacklist();
          saveBlacklistSettings();
        } else {
          alert("Это слово уже есть в списке.");
        }
      }
    });
    newTextBlacklistWordInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') addTextWordBtn.click();
    });
  }

  function renderImageBlacklist() {
    if(!userImageBlacklistUl) return;
    userImageBlacklistUl.innerHTML = '';
    (currentSettings.userImageBlacklist || []).forEach((rule, index) => {
      const li = document.createElement('li');
      const spanType = document.createElement('span');
      spanType.className = 'list-item-type';
      spanType.textContent = rule.type ? rule.type.toUpperCase() : 'N/A';
      li.appendChild(spanType);
      
      const spanValue = document.createElement('span');
      spanValue.className = 'list-item-value';
      spanValue.textContent = rule.value;
      li.appendChild(spanValue);

      const removeBtn = document.createElement('button');
      removeBtn.innerHTML = '&#10007;';
      removeBtn.className = 'remove-btn';
      removeBtn.title = 'Удалить';
      removeBtn.dataset.index = index;
      removeBtn.addEventListener('click', (e) => {
        const itemIndex = parseInt(e.target.dataset.index, 10);
         if (!isNaN(itemIndex) && itemIndex >= 0 && itemIndex < currentSettings.userImageBlacklist.length) {
            currentSettings.userImageBlacklist.splice(itemIndex, 1);
            renderImageBlacklist();
            saveBlacklistSettings();
        }
      });
      li.appendChild(removeBtn);
      userImageBlacklistUl.appendChild(li);
    });
  }

  if (addImageRuleBtn && newImageUrlOrKeywordInput && imageRuleTypeSelect) {
    addImageRuleBtn.addEventListener('click', () => {
      const value = newImageUrlOrKeywordInput.value.trim();
      const type = imageRuleTypeSelect.value;
      if (value) {
        if (!currentSettings.userImageBlacklist) currentSettings.userImageBlacklist = [];
        const valueLower = value.toLowerCase();
        const exists = currentSettings.userImageBlacklist.some(
          rule => rule.type === type && rule.value.toLowerCase() === valueLower
        );
        if (!exists) {
          currentSettings.userImageBlacklist.push({ type: type, value: value });
          newImageUrlOrKeywordInput.value = '';
          renderImageBlacklist();
          saveBlacklistSettings();
        } else {
          alert("Это правило (тип + значение) уже существует.");
        }
      }
    });
    newImageUrlOrKeywordInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') addImageRuleBtn.click();
    });
  }

  function updateMlTextSettingsVisibility() {
    if (mlTextSettingsSection && textFilterToggleOpts && mlTextFilterToggleOpts) {
        const enableMlSection = textFilterToggleOpts.checked && mlTextFilterToggleOpts.checked;
        mlTextSettingsSection.style.display = enableMlSection ? '' : 'none';
        
        mlTextFilterToggleOpts.disabled = !textFilterToggleOpts.checked;
        const parentLabel = mlTextFilterToggleOpts.closest('.setting-toggle');
        if(parentLabel){
            parentLabel.classList.toggle('disabled-setting', !textFilterToggleOpts.checked);
        }
        if (!textFilterToggleOpts.checked) {
             if (mlTextFilterToggleOpts.checked) {
                mlTextFilterToggleOpts.checked = false;
                saveSpecificSettings({ mlTextFilterEnabled: false });
             }
        }
    }
  }

  if (textFilterToggleOpts) {
    textFilterToggleOpts.addEventListener('change', () => {
      saveSpecificSettings({ textFilterEnabled: textFilterToggleOpts.checked });
      updateMlTextSettingsVisibility();
    });
  }

  if (mlTextFilterToggleOpts) {
    mlTextFilterToggleOpts.addEventListener('change', () => {
      saveSpecificSettings({ mlTextFilterEnabled: mlTextFilterToggleOpts.checked });
      updateMlTextSettingsVisibility();
    });
  }
  
  if (imageBlurToggleOpts) {
    imageBlurToggleOpts.addEventListener('change', () => {
      saveSpecificSettings({ imageBlurEnabled: imageBlurToggleOpts.checked });
    });
  }

  if (mlTextThresholdInput) {
    mlTextThresholdInput.addEventListener('input', () => {
      let value = parseFloat(mlTextThresholdInput.value);
      if (!isNaN(value)) {
        saveSpecificSettings({ mlTextThreshold: value });
        console.log("CleanWEB Options: mlTextThreshold changed via 'input' event, sent for saving:", value);
      }
    });
    mlTextThresholdInput.addEventListener('change', () => {
      let value = parseFloat(mlTextThresholdInput.value);
      if (isNaN(value) || value < 0.1) value = 0.1;
      if (value > 1.0) value = 1.0;
      mlTextThresholdInput.value = value.toFixed(2);
      if (currentSettings.mlTextThreshold !== value) { 
          saveSpecificSettings({ mlTextThreshold: value });
          console.log("CleanWEB Options: mlTextThreshold corrected on 'change' event and saved:", value);
          currentSettings.mlTextThreshold = value;
      }
    });
  }

  function renderDefaultList(ulElement, listArray) {
      if (!ulElement || !Array.isArray(listArray)) return;
      ulElement.innerHTML = '';
      if (listArray.length === 0) {
          const li = document.createElement('li');
          li.textContent = "Список пуст.";
          li.style.justifyContent = "center";
          li.style.color = "#777";
          ulElement.appendChild(li);
          return;
      }
      listArray.forEach(item => {
          const li = document.createElement('li');
          const spanValue = document.createElement('span');
          spanValue.className = 'list-item-value';
          spanValue.textContent = item;
          li.appendChild(spanValue);
          ulElement.appendChild(li);
      });
  }

  function loadInitialSettings() {
    chrome.runtime.sendMessage({ action: "getSettings" }, (settingsFromBg) => {
      if (chrome.runtime.lastError) {
          console.error("CleanWEB Options: Error loading initial settings:", chrome.runtime.lastError.message);
          console.warn("CleanWEB Options: Using default page settings structure due to error.");
      } else {
          console.log("CleanWEB Options: Settings received from background.", settingsFromBg);
          currentSettings = { ...defaultPageSettings, ...settingsFromBg };
      }
      
      currentSettings.userTextBlacklist = Array.isArray(currentSettings.userTextBlacklist) ? currentSettings.userTextBlacklist : [];
      currentSettings.userImageBlacklist = Array.isArray(currentSettings.userImageBlacklist) ? currentSettings.userImageBlacklist : [];
      currentSettings.defaultTextBlacklist = Array.isArray(currentSettings.defaultTextBlacklist) ? currentSettings.defaultTextBlacklist : [];
      currentSettings.defaultImageKeywords = Array.isArray(currentSettings.defaultImageKeywords) ? currentSettings.defaultImageKeywords : [];
      currentSettings.mlTextThreshold = typeof currentSettings.mlTextThreshold === 'number' ? currentSettings.mlTextThreshold : defaultPageSettings.mlTextThreshold;
      currentSettings.mlTextFilterEnabled = typeof currentSettings.mlTextFilterEnabled === 'boolean' ? currentSettings.mlTextFilterEnabled : defaultPageSettings.mlTextFilterEnabled;
      currentSettings.textFilterEnabled = typeof currentSettings.textFilterEnabled === 'boolean' ? currentSettings.textFilterEnabled : defaultPageSettings.textFilterEnabled;
      currentSettings.imageBlurEnabled = typeof currentSettings.imageBlurEnabled === 'boolean' ? currentSettings.imageBlurEnabled : defaultPageSettings.imageBlurEnabled;

      if (textFilterToggleOpts) textFilterToggleOpts.checked = currentSettings.textFilterEnabled;
      if (mlTextFilterToggleOpts) mlTextFilterToggleOpts.checked = currentSettings.mlTextFilterEnabled;
      if (imageBlurToggleOpts) imageBlurToggleOpts.checked = currentSettings.imageBlurEnabled;
      if (mlTextThresholdInput) mlTextThresholdInput.value = Number(currentSettings.mlTextThreshold).toFixed(2);
      
      updateMlTextSettingsVisibility(); 

      renderTextBlacklist();
      renderImageBlacklist();
      
      renderDefaultList(defaultTextBlacklistDisplayUl, currentSettings.defaultTextBlacklist);
      renderDefaultList(defaultImageKeywordsDisplayUl, currentSettings.defaultImageKeywords);

      console.log("CleanWEB Options: Final currentSettings after load:", JSON.parse(JSON.stringify(currentSettings)));
    });
  }
  
  loadInitialSettings();
  console.log("CleanWEB Options script loaded and listeners attached.");
});